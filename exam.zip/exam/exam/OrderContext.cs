﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exam
{
    class OrderContext : DbContext
    {
        public OrderContext() : base("DbConnection")
        { }

        public DbSet<Order> Orders { get; set; }
    }
}
