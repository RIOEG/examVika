﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exam
{
    public partial class MainEmployee : Form
    {
        OrderContext db;

        public MainEmployee()
        {
            InitializeComponent();
            db = new OrderContext();
            db.Orders.Load();

            dataGridView1.DataSource = db.Orders.Local.ToBindingList();
        }

        private void AddOrder_Click(object sender, EventArgs e)
        {
            EmployeeAddForm orForm = new EmployeeAddForm();
            DialogResult result = orForm.ShowDialog(this);

            if (result == DialogResult.Cancel)
                return;

            Order order = new Order();
            order.Name = orForm.nameInput.Text;
            order.Specialty = orForm.specialtyInput.Text;
            order.Phone = orForm.phoneInput.Text;
            order.Age = (int)orForm.ageNumericUpDown.Value;
            order.Experience = (int)orForm.experienceSenumericUpDown2.Value;
            order.Sex = orForm.sexDropList.SelectedItem.ToString();

            db.Orders.Add(order);
            db.SaveChanges();

            MessageBox.Show("Новый заказ добавлен");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void EditOrder_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            int id = 0;
            bool converted = Int32.TryParse(dataGridView1[0, index].Value.ToString(), out id);
            if (converted == false)
                return;
            Order order = db.Orders.Find(id);

            EmployeeAddForm orForm = new EmployeeAddForm();
            orForm.nameInput.Text = order.Name;
            orForm.specialtyInput.Text = order.Specialty;
            orForm.phoneInput.Text = order.Phone;
            orForm.ageNumericUpDown.Value = order.Age;
            orForm.experienceSenumericUpDown2.Value = order.Experience;
            orForm.sexDropList.SelectedItem = order.Sex;


           DialogResult result = orForm.ShowDialog(this);
            if (result == DialogResult.Cancel)
                return;


            order.Name = orForm.nameInput.Text;
            order.Specialty = orForm.specialtyInput.Text;
            order.Phone = orForm.phoneInput.Text;
            order.Age = (int)orForm.ageNumericUpDown.Value;
            order.Experience = (int)orForm.experienceSenumericUpDown2.Value;
            order.Sex = orForm.sexDropList.SelectedItem.ToString();

            db.SaveChanges();
            dataGridView1.Refresh();
            MessageBox.Show("Заказ обновлен");
        }

        private void DeleteOrder_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            int id = 0;
            bool converted = Int32.TryParse(dataGridView1[0, index].Value.ToString(), out id);
            if (converted == false)
                return;
            Order order = db.Orders.Find(id);
            db.Orders.Remove(order);
            db.SaveChanges();
            dataGridView1.Refresh();
            MessageBox.Show("Заказ Удален");

        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
