﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exam
{
    public partial class Vacancy : Form
    {
        public Vacancy()
        {
            InitializeComponent();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            
            string speciality = textBox1.Text;
            string sex = sexDropList.SelectedItem.ToString(); 
            int age = (int)ageNumericUpDown.Value;
            int exp = (int)experienceSenumericUpDown2.Value;

            if (speciality!="" || sex!="" || age!=0 || exp != 0) { 


                    using (OrderContext db = new OrderContext())
                {
                    var employees = db.Orders
                        .Where(em => em.Specialty == speciality)
                        .Where(em => em.Sex == sex)
                        .Where(em => em.Age == age)
                        .Where(em => em.Experience == exp)
                        .ToList();
                    foreach (var employee in employees)
                    {
                   
                        listBox1.Items.Add(employee.Name);
                    }
                }
            }
            else MessageBox.Show("Заполните все поля");
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
